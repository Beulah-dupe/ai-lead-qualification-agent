/**
 * Smoke test: posts a sample lead to the running agent and prints
 * Claude's qualification decision. Requires ANTHROPIC_API_KEY to be
 * set in your environment. Run with: npm test
 */
const http = require("http");
const samplePayload = require("./sample-payload.json");

require("../server.js");

const data = JSON.stringify(samplePayload);

setTimeout(() => {
  const req = http.request(
    {
      hostname: "localhost",
      port: process.env.PORT || 3000,
      path: "/agent/qualify-lead",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Content-Length": data.length,
      },
    },
    (res) => {
      let body = "";
      res.on("data", (chunk) => (body += chunk));
      res.on("end", () => {
        console.log("Response status:", res.statusCode);
        console.log("Response body:", body);
        process.exit(0);
      });
    }
  );

  req.on("error", (e) => {
    console.error("Test request failed:", e.message);
    process.exit(1);
  });

  req.write(data);
  req.end();
}, 500);
